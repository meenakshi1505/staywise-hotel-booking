# StayWise — Hotel Booking Application with an AI Search Agent

A front-end demo of a hotel booking flow where hotel search is driven by a
conversational agent instead of manual filter forms, following the workflow:

Login/Register → Search Hotel (via agent) → View Results → Hotel Details →
Select Room → Guest Details → Apply Coupon → Payment → Confirmation → My Bookings

## How to run

No build step or server is required for the core app.

- **Quickest:** open `index.html` directly in a browser.
- **Recommended (avoids some browsers' file:// restrictions):** run a local
  server from this folder, e.g. `python3 -m http.server 8000`, then open
  `http://localhost:8000`.

## How the "AI agent" works (`js/agent.js`)

The assignment brief asks for a hotel search agent that lets the user type a
request in plain language instead of filling filters one by one, e.g.:

> "I need a hotel in Chennai for 2 people from September 10 to 12, under
> ₹3,000 per night, preferably near the beach."

This project implements that pipeline **fully client-side**, with a rule-based
parser standing in for an LLM call (no API key or backend needed for the demo,
and it stays deterministic and gradeable):

1. **User Request** — the free-text box on the home page.
2. **Understand Intent** — `extractInfo()` confirms the text is a hotel search.
3. **Extract Information** — regex/keyword matching pulls out city, guest
   count, budget, date range, and preferences (beach, pool, breakfast, budget,
   etc.) from the sentence.
4. **Search Available Hotels** — `searchAndFilter()` runs those fields against
   the mock hotel catalogue in `js/data.js`.
5. **Apply Filters** — narrows by city, capacity, budget and preference tags.
6. **Compare Options** — `rankHotels()` scores the shortlist by rating and
   price.
7. **Recommend** — the top 3–5 hotels are shown with the reasoning ("Based on
   your budget and preference, I recommend these 3 hotels…") in the results
   page's agent bubble.

Running the exact example above returns the same three hotels, prices, and
distances used as the worked example in the assignment brief — see the
`How the agent works` walkthrough on the home page for the same explanation
shown to the user.

If you want to swap the rule-based parser for a real LLM call later, only
`extractInfo()` in `js/agent.js` needs to change — call your model of choice,
have it return the same `{city, guests, budget, checkin, checkout,
preferences}` shape, and the rest of the pipeline (search/filter/rank/render)
stays untouched.

## Project structure

```
index.html              Page shell, nav, script loading order
css/styles.css           All styling (single stylesheet)
js/data.js               Mock hotels + coupon codes
js/agent.js              The search agent (parse → filter → rank → recommend)
js/state.js              Central app state store (pub/sub) + localStorage persistence
js/app.js                View router
js/views/landing.js      Home page: agent chat box + manual filter fallback
js/views/auth.js         Login / Register (stored in localStorage, demo only)
js/views/results.js      Agent's recommended hotel list
js/views/hotelDetails.js Hotel detail page
js/views/rooms.js        Room selection
js/views/guestDetails.js Guest details form
js/views/payment.js      Coupon code + mock payment + totals
js/views/confirmation.js Booking confirmation
js/views/myBookings.js   Booking history + cancel
```

## Using the n8n workflow (optional, replaces the local agent)

A ready-to-import n8n workflow (`StayWise_n8n_workflow.json`) runs the exact
same search-agent pipeline server-side in n8n instead of in the browser.

1. In n8n: **Workflows → Import from File**, select `StayWise_n8n_workflow.json`.
2. Open the **Webhook** node, click **Listen for Test Event** (or Activate the
   workflow for the production URL), and copy the webhook URL shown.
3. In `js/views/landing.js`, set:
   ```js
   const N8N_WEBHOOK_URL = "https://your-n8n-instance/webhook/hotel-search";
   ```
4. Reload `index.html`. Every agent search now POSTs `{ query: text }` to n8n,
   which runs Webhook → Code (extract/search/filter/rank) → Respond to
   Webhook, and returns `{ info, results, summary }` for the results page.

If the webhook is unreachable (CORS, n8n not running, wrong URL), the app
automatically falls back to the built-in local agent (`js/agent.js`) so the
demo never breaks — check the browser console for a warning if that happens.

To make it genuinely LLM-driven instead of rule-based, replace the **Code**
node with an **AI Agent** / **Message a Model** node (Claude or OpenAI
credentials) that returns the same `{city, guests, budget, checkin,
checkout, preferences}` JSON shape, then keep a Code node after it for the
search/filter/rank step.

## Notes for the assignment write-up

- Login/auth and bookings are stored only in the browser's `localStorage` —
  there's no real backend, database, or payment gateway. This keeps the demo
  self-contained and safe to submit, while still showing the complete
  workflow end-to-end.
- Try coupon codes `SAVE10`, `FIRST500`, or `BEACH15` on the payment page.
- The four example chips on the home page are pre-written to showcase
  different extraction cases (dates + budget + preference, preference only,
  budget + preference, guest count + preference).

## Documents

- `docs/StayWise_Project_Report.pdf` - project report
- `docs/StayWise_Presentation.pdf` - team presentation slides

## Team

- Muthumeenakshi Devi (23IT089)
- [Add team member 2]
- [Add team member 3]
