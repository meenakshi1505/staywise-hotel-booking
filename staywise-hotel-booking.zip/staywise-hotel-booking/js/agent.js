/* ==========================================================================
   StayWise - Hotel Search Agent
   Turns a free-text request into structured filters, then searches,
   filters, compares and recommends hotels. Mirrors the workflow:
   Understand Intent -> Extract Info -> Search -> Filter -> Compare -> Recommend
   ========================================================================== */
(function () {
  window.StayWiseAgent = window.StayWiseAgent || {};

  const MONTHS = ["january","february","march","april","may","june","july","august","september","october","november","december"];
  const PREFERENCE_KEYWORDS = {
    beach: ["beach", "sea", "coast", "coastal"],
    city: ["city", "downtown", "central", "mall", "shopping"],
    hills: ["hill", "hills", "mountain", "valley"],
    pool: ["pool", "swimming"],
    breakfast: ["breakfast"],
    wifi: ["wifi", "wi-fi", "internet"],
    budget: ["cheap", "budget", "affordable", "low cost", "low-cost"],
    luxury: ["luxury", "premium", "5 star", "five star"]
  };

  // ---- 2 & 3. Understand Intent + Extract Information -------------------
  function extractInfo(text) {
    const lower = text.toLowerCase();
    const info = {
      rawText: text,
      city: null,
      guests: null,
      budget: null,
      checkin: null,
      checkout: null,
      preferences: []
    };

    // City
    const aliases = window.StayWiseData.CITY_ALIASES;
    for (const city in aliases) {
      if (aliases[city].some(a => lower.includes(a))) {
        info.city = city;
        break;
      }
    }

    // Guests: "2 people", "for two", "2 guests", "party of 4"
    const numWords = { one: 1, two: 2, three: 3, four: 4, five: 5, six: 6 };
    let guestMatch = lower.match(/(\d+)\s*(people|person|guests?|pax|adults?)/);
    if (guestMatch) {
      info.guests = parseInt(guestMatch[1], 10);
    } else {
      for (const w in numWords) {
        if (lower.match(new RegExp("for\\s+" + w + "\\b")) || lower.match(new RegExp(w + "\\s+(people|guests|of us)"))) {
          info.guests = numWords[w];
          break;
        }
      }
    }

    // Budget: "under 3000", "below ₹3,000", "3000 per night", "<=3000"
    let budgetMatch = lower.match(/(?:under|below|less than|within|up to|max(?:imum)?)\s*(?:rs\.?|inr|₹)?\s*(\d[\d,]*)/);
    if (!budgetMatch) budgetMatch = lower.match(/(?:rs\.?|inr|₹)\s*(\d[\d,]*)/);
    if (budgetMatch) {
      info.budget = parseInt(budgetMatch[1].replace(/,/g, ""), 10);
    }

    // Dates: "from September 10 to 12", "Sep 10-12"
    const dateRange = lower.match(/(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+(\d{1,2})\s*(?:to|-|–)\s*(\d{1,2})/);
    if (dateRange) {
      const monthName = MONTHS.find(m => m.startsWith(dateRange[1])) || dateRange[1];
      info.checkin = capitalize(monthName) + " " + dateRange[2];
      info.checkout = capitalize(monthName) + " " + dateRange[3];
    }

    // Preferences
    for (const key in PREFERENCE_KEYWORDS) {
      if (PREFERENCE_KEYWORDS[key].some(kw => lower.includes(kw))) {
        info.preferences.push(key);
      }
    }

    return info;
  }

  function capitalize(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

  // ---- 4 & 5. Search + Apply Filters -------------------------------------
  function searchAndFilter(info) {
    let results = window.StayWiseData.HOTELS.slice();

    if (info.city) {
      results = results.filter(h => h.city === info.city);
    }
    if (info.guests) {
      results = results.filter(h => h.capacity >= info.guests);
    }
    if (info.budget) {
      results = results.filter(h => h.pricePerNight <= info.budget);
    }
    if (info.preferences.length) {
      const wantsBudget = info.preferences.includes("budget");
      const tagPrefs = info.preferences.filter(p => p !== "budget" && p !== "luxury");
      if (tagPrefs.length) {
        const matched = results.filter(h => tagPrefs.some(p => h.tags.includes(p)));
        if (matched.length) results = matched;
      }
      if (wantsBudget) {
        results = results.slice().sort((a, b) => a.pricePerNight - b.pricePerNight);
      }
    }
    return results;
  }

  // ---- 6. Compare Options -------------------------------------------------
  function rankHotels(results) {
    return results.slice().sort((a, b) => {
      const scoreA = a.rating * 20 - a.pricePerNight / 200;
      const scoreB = b.rating * 20 - b.pricePerNight / 200;
      return scoreB - scoreA;
    });
  }

  // ---- 7. Recommend --------------------------------------------------------
  function buildRecommendationMessage(info, ranked) {
    if (!ranked.length) {
      return "I couldn't find a hotel that matches every filter. Try loosening the budget or dropping a preference, and I'll search again.";
    }
    const top = ranked.slice(0, Math.min(5, ranked.length));
    const cityLabel = info.city ? capitalize(info.city) : "your destination";
    let msg = "Based on your budget and preferences, here " + (top.length > 1 ? "are" : "is") + " " + top.length +
      " good option" + (top.length > 1 ? "s" : "") + " in " + cityLabel + ":";
    return { summary: msg, top };
  }

  // ---- Full pipeline, used by the UI ---------------------------------------
  function runAgent(text) {
    const info = extractInfo(text);
    const searched = searchAndFilter(info);
    const ranked = rankHotels(searched);
    const recommendation = buildRecommendationMessage(info, ranked);
    return { info, results: ranked, recommendation };
  }

  window.StayWiseAgent.extractInfo = extractInfo;
  window.StayWiseAgent.searchAndFilter = searchAndFilter;
  window.StayWiseAgent.rankHotels = rankHotels;
  window.StayWiseAgent.runAgent = runAgent;
})();
