/* ==========================================================================
   StayWise - App Controller & Router
   ========================================================================== */
(function () {
  function renderNav(state) {
    const nav = document.getElementById("nav-links");
    if (!nav) return;
    const user = state.user;
    nav.innerHTML = `
      <a href="#" class="nav-link" onclick="window.StayWiseState.navigateTo('landing'); return false;">Search</a>
      <a href="#" class="nav-link" onclick="window.StayWiseState.navigateTo('myBookings'); return false;">My bookings</a>
      ${user ? `
        <span class="nav-user"><i data-lucide="user-circle"></i> ${escapeHtml(user.name)}</span>
        <a href="#" class="nav-link" onclick="window.StayWiseAuth.logout(); return false;">Log out</a>
      ` : `
        <a href="#" class="nav-link" onclick="window.StayWiseState.navigateTo('login'); return false;">Log in</a>
      `}
    `;
  }

  function renderView() {
    const state = window.StayWiseState.get();
    const container = document.getElementById("app-view");
    if (!container) return;

    const viewFn = window.StayWiseViews[state.currentView];
    container.innerHTML = viewFn ? viewFn(state) : window.StayWiseViews.landing(state);

    renderNav(state);

    if (window.lucide) window.lucide.createIcons();
  }

  function escapeHtml(str) {
    return String(str || "").replace(/[&<>"']/g, s => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[s]);
  }

  document.addEventListener("DOMContentLoaded", function () {
    window.StayWiseState.subscribe(renderView);
    renderView();
  });
})();
