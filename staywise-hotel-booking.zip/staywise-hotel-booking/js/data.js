/* ==========================================================================
   StayWise - Mock Hotel & Coupon Data
   ========================================================================== */
(function () {
  window.StayWiseData = window.StayWiseData || {};

  const HOTELS = [
    { id: "htl_001", name: "Marina Bay Residency", city: "chennai", area: "Besant Nagar",
      landmark: "beach", distanceLabel: "500m from beach", pricePerNight: 2700, rating: 4.6,
      reviews: 812, capacity: 3, tags: ["beach", "wifi", "breakfast", "ac"], accent: "#1F6F5C",
      description: "A relaxed, mid-century-styled residency two streets from Besant Nagar beach, favoured by couples and small families who want quiet mornings and easy sea breeze.",
      amenities: ["Free Wi-Fi", "Breakfast included", "Air conditioning", "24-hour front desk", "Airport pickup"],
      rooms: [
        { id: "rm_001a", type: "Standard Sea-View", price: 2700, capacity: 2, amenities: ["Queen bed", "Sea view", "Free Wi-Fi"] },
        { id: "rm_001b", type: "Family Suite", price: 3900, capacity: 4, amenities: ["Two rooms", "Sea view", "Breakfast for 4"] }
      ] },
    { id: "htl_002", name: "Bayview Inn", city: "chennai", area: "Thiruvanmiyur",
      landmark: "beach", distanceLabel: "300m from beach", pricePerNight: 2900, rating: 4.5,
      reviews: 604, capacity: 2, tags: ["beach", "wifi", "pool"], accent: "#C9683B",
      description: "A compact boutique inn with a rooftop pool overlooking the coast - best suited to travellers who want a short walk to the water and a lively neighbourhood of cafes.",
      amenities: ["Rooftop pool", "Free Wi-Fi", "Restaurant", "Laundry service"],
      rooms: [ { id: "rm_002a", type: "Deluxe Room", price: 2900, capacity: 2, amenities: ["King bed", "Pool access", "Free Wi-Fi"] } ] },
    { id: "htl_003", name: "Coral Sands Budget Stay", city: "chennai", area: "Thiruvanmiyur",
      landmark: "beach", distanceLabel: "800m from beach", pricePerNight: 2500, rating: 4.3,
      reviews: 389, capacity: 4, tags: ["beach", "wifi", "budget"], accent: "#2C5F8A",
      description: "No-frills budget rooms for travellers who mainly want a clean bed and proximity to the beach without paying for extras they won't use.",
      amenities: ["Free Wi-Fi", "Fan & AC rooms", "Locker facility"],
      rooms: [
        { id: "rm_003a", type: "Economy Room", price: 2500, capacity: 2, amenities: ["Twin beds", "Free Wi-Fi"] },
        { id: "rm_003b", type: "Family Room", price: 3200, capacity: 4, amenities: ["Two double beds", "Free Wi-Fi"] }
      ] },
    { id: "htl_004", name: "T.Nagar Business Suites", city: "chennai", area: "T. Nagar",
      landmark: "city", distanceLabel: "2.1km from Pondy Bazaar", pricePerNight: 3400, rating: 4.4,
      reviews: 421, capacity: 3, tags: ["city", "wifi", "breakfast", "workdesk"], accent: "#4A3B78",
      description: "A workday-friendly hotel in the middle of the shopping district, with fast Wi-Fi and desks in every room for guests mixing business with a bit of sightseeing.",
      amenities: ["Work desk", "Free Wi-Fi", "Breakfast included", "Gym"],
      rooms: [ { id: "rm_004a", type: "Executive Room", price: 3400, capacity: 2, amenities: ["Work desk", "Free Wi-Fi", "Breakfast"] } ] },
    { id: "htl_005", name: "Candolim Coconut Grove", city: "goa", area: "Candolim",
      landmark: "beach", distanceLabel: "150m from beach", pricePerNight: 3800, rating: 4.7,
      reviews: 1120, capacity: 4, tags: ["beach", "pool", "breakfast", "wifi"], accent: "#1F8A70",
      description: "Palm-shaded cottages a short sandy walk from Candolim beach, with a pool for the middle of the day and hammocks for the evening.",
      amenities: ["Swimming pool", "Free Wi-Fi", "Breakfast included", "Beach shuttle"],
      rooms: [
        { id: "rm_005a", type: "Garden Cottage", price: 3800, capacity: 2, amenities: ["Garden view", "Free Wi-Fi"] },
        { id: "rm_005b", type: "Pool-Facing Cottage", price: 4600, capacity: 4, amenities: ["Pool view", "Breakfast for 4"] }
      ] },
    { id: "htl_006", name: "Koramangala Central", city: "bangalore", area: "Koramangala",
      landmark: "city", distanceLabel: "1.5km from Forum Mall", pricePerNight: 3100, rating: 4.5,
      reviews: 567, capacity: 3, tags: ["city", "wifi", "breakfast"], accent: "#B5501F",
      description: "A dependable stay in Bangalore's cafe district, popular with guests who want to walk to restaurants and co-working spaces rather than take a cab everywhere.",
      amenities: ["Free Wi-Fi", "Breakfast included", "Rooftop cafe", "Gym"],
      rooms: [ { id: "rm_006a", type: "Standard Room", price: 3100, capacity: 2, amenities: ["Queen bed", "Free Wi-Fi"] } ] },
    { id: "htl_007", name: "Colaba Heritage Hotel", city: "mumbai", area: "Colaba",
      landmark: "city", distanceLabel: "600m from Gateway of India", pricePerNight: 4200, rating: 4.6,
      reviews: 933, capacity: 2, tags: ["city", "wifi", "heritage"], accent: "#7A2E2E",
      description: "A restored heritage building near the Gateway of India, with high ceilings and a lobby that has clearly seen a century of guests come and go.",
      amenities: ["Free Wi-Fi", "Concierge", "Restaurant", "Heritage architecture"],
      rooms: [ { id: "rm_007a", type: "Heritage Room", price: 4200, capacity: 2, amenities: ["City view", "Free Wi-Fi"] } ] },
    { id: "htl_008", name: "Ooty Hillside Cottages", city: "ooty", area: "Fern Hill",
      landmark: "hills", distanceLabel: "3km from Botanical Garden", pricePerNight: 2800, rating: 4.5,
      reviews: 298, capacity: 5, tags: ["hills", "breakfast", "wifi", "budget"], accent: "#3C6E47",
      description: "Wood-panelled cottages tucked into a pine slope, built for families who want a fireplace in the evening and a view of the valley in the morning.",
      amenities: ["Fireplace", "Free Wi-Fi", "Breakfast included", "Valley view"],
      rooms: [
        { id: "rm_008a", type: "Cottage Room", price: 2800, capacity: 3, amenities: ["Fireplace", "Valley view"] },
        { id: "rm_008b", type: "Family Cottage", price: 3600, capacity: 5, amenities: ["Two bedrooms", "Fireplace"] }
      ] }
  ];

  const COUPONS = {
    "FIRST500": { type: "flat", value: 500, minAmount: 2000, description: "Rs.500 off on your first booking" },
    "SAVE10": { type: "percent", value: 10, minAmount: 0, description: "10% off your total" },
    "BEACH15": { type: "percent", value: 15, minAmount: 3000, description: "15% off beach stays over Rs.3,000" }
  };

  const CITY_ALIASES = {
    chennai: ["chennai", "madras"],
    goa: ["goa", "candolim", "calangute"],
    bangalore: ["bangalore", "bengaluru", "koramangala"],
    mumbai: ["mumbai", "bombay", "colaba"],
    ooty: ["ooty", "udhagamandalam"]
  };

  window.StayWiseData.HOTELS = HOTELS;
  window.StayWiseData.COUPONS = COUPONS;
  window.StayWiseData.CITY_ALIASES = CITY_ALIASES;
})();
