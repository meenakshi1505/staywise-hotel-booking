/* ==========================================================================
   StayWise - Central Application State
   ========================================================================== */
(function () {
  const LISTENERS = [];

  const state = {
    currentView: "landing",
    user: loadUser(),

    // Search / agent state
    lastQueryText: "",
    lastAgentInfo: null,
    searchResults: [],
    agentSummary: "",

    // Booking-in-progress state
    selectedHotelId: null,
    selectedRoomId: null,
    guestDetails: null,
    appliedCoupon: null,
    lastBooking: null,

    // My Bookings
    bookings: loadBookings()
  };

  function loadUser() {
    try {
      const raw = localStorage.getItem("staywise_user");
      return raw ? JSON.parse(raw) : null;
    } catch (e) { return null; }
  }

  function loadBookings() {
    try {
      const raw = localStorage.getItem("staywise_bookings");
      return raw ? JSON.parse(raw) : [];
    } catch (e) { return []; }
  }

  function persistUser() {
    if (state.user) localStorage.setItem("staywise_user", JSON.stringify(state.user));
    else localStorage.removeItem("staywise_user");
  }

  function persistBookings() {
    localStorage.setItem("staywise_bookings", JSON.stringify(state.bookings));
  }

  function get() { return state; }

  function set(patch) {
    Object.assign(state, patch);
    if (Object.prototype.hasOwnProperty.call(patch, "user")) persistUser();
    if (Object.prototype.hasOwnProperty.call(patch, "bookings")) persistBookings();
    notify();
  }

  function navigateTo(view) {
    set({ currentView: view });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function subscribe(fn) { LISTENERS.push(fn); }
  function notify() { LISTENERS.forEach(fn => fn(state)); }

  function findHotel(id) {
    return window.StayWiseData.HOTELS.find(h => h.id === id) || null;
  }

  function findRoom(hotel, roomId) {
    if (!hotel) return null;
    return hotel.rooms.find(r => r.id === roomId) || null;
  }

  function addBooking(booking) {
    const bookings = state.bookings.slice();
    bookings.unshift(booking);
    set({ bookings });
  }

  function cancelBooking(bookingId) {
    const bookings = state.bookings.map(b =>
      b.id === bookingId ? Object.assign({}, b, { status: "cancelled" }) : b
    );
    set({ bookings });
  }

  window.StayWiseState = {
    get, set, navigateTo, subscribe,
    findHotel, findRoom, addBooking, cancelBooking
  };
})();
