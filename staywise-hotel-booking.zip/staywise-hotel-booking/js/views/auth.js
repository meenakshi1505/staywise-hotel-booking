/* ==========================================================================
   StayWise - Login / Register View
   ========================================================================== */
(function () {
  window.StayWiseViews = window.StayWiseViews || {};

  function loadUsers() {
    try {
      const raw = localStorage.getItem("staywise_users");
      return raw ? JSON.parse(raw) : {};
    } catch (e) { return {}; }
  }
  function saveUsers(users) {
    localStorage.setItem("staywise_users", JSON.stringify(users));
  }

  window.StayWiseAuth = {
    login: function (email, password) {
      const users = loadUsers();
      const record = users[email];
      if (!record || record.password !== password) {
        return { ok: false, message: "That email and password don't match our records." };
      }
      window.StayWiseState.set({ user: { name: record.name, email: email } });
      return { ok: true };
    },
    register: function (name, email, password) {
      const users = loadUsers();
      if (users[email]) {
        return { ok: false, message: "An account with this email already exists. Try logging in." };
      }
      users[email] = { name: name, password: password };
      saveUsers(users);
      window.StayWiseState.set({ user: { name: name, email: email } });
      return { ok: true };
    },
    logout: function () {
      window.StayWiseState.set({ user: null });
      window.StayWiseState.navigateTo("landing");
    }
  };

  function authView(mode) {
    const isLogin = mode !== "register";
    return `
      <section class="auth-shell">
        <div class="auth-card">
          <div class="auth-tabs">
            <button class="auth-tab ${isLogin ? 'active' : ''}" onclick="window.StayWiseState.navigateTo('login')">Log in</button>
            <button class="auth-tab ${!isLogin ? 'active' : ''}" onclick="window.StayWiseState.navigateTo('register')">Register</button>
          </div>

          <div id="auth-error" class="auth-error hidden"></div>

          ${isLogin ? `
            <form id="login-form" class="auth-form" onsubmit="return window.handleLogin(event)">
              <label>Email
                <input type="email" name="email" required placeholder="you@example.com" />
              </label>
              <label>Password
                <input type="password" name="password" required placeholder="••••••••" />
              </label>
              <button type="submit" class="btn btn-primary btn-block">Log in</button>
            </form>
          ` : `
            <form id="register-form" class="auth-form" onsubmit="return window.handleRegister(event)">
              <label>Full name
                <input type="text" name="name" required placeholder="Your name" />
              </label>
              <label>Email
                <input type="email" name="email" required placeholder="you@example.com" />
              </label>
              <label>Password
                <input type="password" name="password" required minlength="4" placeholder="At least 4 characters" />
              </label>
              <button type="submit" class="btn btn-primary btn-block">Create account</button>
            </form>
          `}

          <p class="auth-hint">This is a demo login stored only in your browser — no real accounts or data leave this device.</p>
        </div>
      </section>
    `;
  }

  window.handleLogin = function (event) {
    event.preventDefault();
    const form = event.target;
    const result = window.StayWiseAuth.login(form.email.value.trim(), form.password.value);
    showAuthResult(result, "landing");
    return false;
  };

  window.handleRegister = function (event) {
    event.preventDefault();
    const form = event.target;
    const result = window.StayWiseAuth.register(form.name.value.trim(), form.email.value.trim(), form.password.value);
    showAuthResult(result, "landing");
    return false;
  };

  function showAuthResult(result, nextView) {
    const errBox = document.getElementById("auth-error");
    if (!result.ok) {
      if (errBox) {
        errBox.textContent = result.message;
        errBox.classList.remove("hidden");
      }
      return;
    }
    window.StayWiseState.navigateTo(nextView);
  }

  window.StayWiseViews.login = () => authView("login");
  window.StayWiseViews.register = () => authView("register");
})();
