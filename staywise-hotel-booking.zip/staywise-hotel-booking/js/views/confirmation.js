/* ==========================================================================
   StayWise - Booking Confirmation View
   ========================================================================== */
(function () {
  window.StayWiseViews = window.StayWiseViews || {};

  function confirmationView(state) {
    const booking = state.lastBooking;
    if (!booking) {
      return `<section class="empty-state"><p>No recent booking found.</p>
        <button class="btn btn-primary" onclick="window.StayWiseState.navigateTo('landing')">Start a search</button></section>`;
    }

    return `
      <section class="confirmation-page">
        <div class="confirmation-icon"><i data-lucide="badge-check"></i></div>
        <h1>Booking confirmed</h1>
        <p class="muted">A confirmation would normally be emailed to ${escapeHtml(booking.guest.email)}.</p>

        <div class="summary-card confirmation-card">
          <div class="confirmation-row"><span class="muted">Booking ID</span><strong>${booking.id}</strong></div>
          <div class="confirmation-row"><span class="muted">Hotel</span><strong>${escapeHtml(booking.hotelName)}</strong></div>
          <div class="confirmation-row"><span class="muted">Room</span><strong>${escapeHtml(booking.roomType)}</strong></div>
          <div class="confirmation-row"><span class="muted">Dates</span><strong>${escapeHtml(booking.guest.checkin)} → ${escapeHtml(booking.guest.checkout)}</strong></div>
          <div class="confirmation-row"><span class="muted">Guests</span><strong>${booking.guest.guests}</strong></div>
          <div class="confirmation-row"><span class="muted">Paid via</span><strong>${cap(booking.paymentMethod)}</strong></div>
          <div class="confirmation-row confirmation-total"><span>Total paid</span><strong>₹${booking.totals.total.toLocaleString("en-IN")}</strong></div>
        </div>

        <div class="confirmation-actions">
          <button class="btn btn-primary" onclick="window.StayWiseState.navigateTo('myBookings')">View my bookings</button>
          <button class="btn btn-ghost" onclick="window.StayWiseState.navigateTo('landing')">Back to home</button>
        </div>
      </section>
    `;
  }

  function cap(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }
  function escapeHtml(str) {
    return String(str || "").replace(/[&<>"']/g, s => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[s]);
  }

  window.StayWiseViews.confirmation = confirmationView;
})();
