/* ==========================================================================
   StayWise - Guest Details View
   ========================================================================== */
(function () {
  window.StayWiseViews = window.StayWiseViews || {};

  function guestDetailsView(state) {
    const hotel = window.StayWiseState.findHotel(state.selectedHotelId);
    const room = window.StayWiseState.findRoom(hotel, state.selectedRoomId);
    if (!hotel || !room) {
      return `<section class="empty-state"><p>Please select a room first.</p>
        <button class="btn btn-primary" onclick="window.StayWiseState.navigateTo('landing')">Start a search</button></section>`;
    }
    const user = state.user;

    return `
      <section class="guest-page">
        <button class="btn btn-ghost" onclick="window.StayWiseState.navigateTo('rooms')">← Back to rooms</button>
        <h2>Guest details</h2>
        <p class="muted">${escapeHtml(hotel.name)} · ${escapeHtml(room.type)} · ₹${room.price.toLocaleString("en-IN")}/night</p>

        <form id="guest-form" class="guest-form" onsubmit="return window.handleGuestDetails(event)">
          <label>Full name
            <input type="text" name="name" required value="${user ? escapeHtml(user.name) : ''}" placeholder="Guest name" />
          </label>
          <label>Email
            <input type="email" name="email" required value="${user ? escapeHtml(user.email) : ''}" placeholder="you@example.com" />
          </label>
          <label>Phone number
            <input type="tel" name="phone" required placeholder="10-digit mobile number" pattern="[0-9]{10}" />
          </label>
          <div class="form-row">
            <label>Check-in
              <input type="date" name="checkin" required />
            </label>
            <label>Check-out
              <input type="date" name="checkout" required />
            </label>
          </div>
          <label>Number of guests
            <input type="number" name="guests" min="1" max="${room.capacity}" value="2" required />
          </label>
          <label>Special requests (optional)
            <textarea name="requests" rows="2" placeholder="e.g. late check-in, extra bed"></textarea>
          </label>
          <button type="submit" class="btn btn-primary btn-block">Continue to payment</button>
        </form>
      </section>
    `;
  }

  window.handleGuestDetails = function (event) {
    event.preventDefault();
    const f = event.target;
    if (new Date(f.checkout.value) <= new Date(f.checkin.value)) {
      alert("Check-out date must be after check-in date.");
      return false;
    }
    window.StayWiseState.set({
      guestDetails: {
        name: f.name.value.trim(),
        email: f.email.value.trim(),
        phone: f.phone.value.trim(),
        checkin: f.checkin.value,
        checkout: f.checkout.value,
        guests: parseInt(f.guests.value, 10),
        requests: f.requests.value.trim()
      },
      appliedCoupon: null
    });
    window.StayWiseState.navigateTo("payment");
    return false;
  };

  function escapeHtml(str) {
    return String(str || "").replace(/[&<>"']/g, s => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[s]);
  }

  window.StayWiseViews.guestDetails = guestDetailsView;
})();
