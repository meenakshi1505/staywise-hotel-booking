/* ==========================================================================
   StayWise - Hotel Details View
   ========================================================================== */
(function () {
  window.StayWiseViews = window.StayWiseViews || {};

  function hotelDetailsView(state) {
    const hotel = window.StayWiseState.findHotel(state.selectedHotelId);
    if (!hotel) {
      return `<section class="empty-state"><p>No hotel selected.</p>
        <button class="btn btn-primary" onclick="window.StayWiseState.navigateTo('landing')">Start a search</button></section>`;
    }

    return `
      <section class="details-page">
        <button class="btn btn-ghost" onclick="window.StayWiseState.navigateTo('results')">← Back to results</button>

        <div class="details-hero" style="background:${hotel.accent}">
          <i data-lucide="building-2"></i>
        </div>

        <div class="details-body">
          <div class="details-head">
            <div>
              <h1>${escapeHtml(hotel.name)}</h1>
              <p class="muted">${escapeHtml(hotel.area)} · ${escapeHtml(hotel.distanceLabel)}</p>
            </div>
            <span class="rating-pill lg"><i data-lucide="star"></i> ${hotel.rating} <span class="muted">(${hotel.reviews} reviews)</span></span>
          </div>

          <p class="details-desc">${escapeHtml(hotel.description)}</p>

          <h3>Amenities</h3>
          <ul class="amenity-list">
            ${hotel.amenities.map(a => `<li><i data-lucide="check"></i> ${escapeHtml(a)}</li>`).join("")}
          </ul>

          <div class="details-cta">
            <div>
              <span class="price">₹${hotel.pricePerNight.toLocaleString("en-IN")}</span>
              <span class="muted"> / night starting price</span>
            </div>
            <button class="btn btn-primary" onclick="window.StayWiseState.navigateTo('rooms')">
              View rooms <i data-lucide="arrow-right"></i>
            </button>
          </div>
        </div>
      </section>
    `;
  }

  function escapeHtml(str) {
    return String(str || "").replace(/[&<>"']/g, s => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[s]);
  }

  window.StayWiseViews.hotelDetails = hotelDetailsView;
})();
