/* ==========================================================================
   StayWise - Landing / Agent Search View
   ========================================================================== */
(function () {
  window.StayWiseViews = window.StayWiseViews || {};

  const EXAMPLES = [
    "A hotel in Chennai for 2 people from September 10 to 12, under ₹3,000 per night, near the beach",
    "Cheap hotel in Goa near the beach with a pool",
    "Business hotel in Bangalore with free wifi, under 3500",
    "Family cottage in Ooty for 5 people with breakfast"
  ];

  const AGENT_STEPS = [
    "Reading your request",
    "Understanding what you need",
    "Extracting location, dates, guests & budget",
    "Searching available hotels",
    "Applying your filters",
    "Comparing price, rating & distance",
    "Preparing recommendations"
  ];

  // Set this to your deployed n8n webhook URL, e.g.
  // "https://your-n8n-instance.app/webhook/hotel-search"
  // Leave it empty ("") to always use the built-in local agent (js/agent.js).
  const N8N_WEBHOOK_URL = "";

  function landingView(state) {
    const user = state.user;
    return `
      <section class="hero">
        <div class="hero-inner">
          <p class="hero-eyebrow">No filters. Just tell us what you're after.</p>
          <h1 class="hero-title">Tell us what you need.<br/>Skip the filter forms.</h1>
          <p class="hero-sub">
            Instead of clicking through location, dates and price filters one by one,
            just describe the stay you want in plain words. The agent reads your
            request, works out what matters to you, and brings back a short list
            worth comparing.
          </p>

          ${user ? `<p class="hero-user">Welcome back, <strong>${escapeHtml(user.name)}</strong>.</p>` :
            `<p class="hero-user hero-user-guest">
               <a href="#" onclick="window.StayWiseState.navigateTo('login'); return false;">Log in</a>
               or <a href="#" onclick="window.StayWiseState.navigateTo('register'); return false;">create an account</a>
               to save bookings to My Bookings.
             </p>`}

          <form id="agent-form" class="agent-box" onsubmit="return window.handleAgentSearch(event)">
            <textarea id="agent-input" rows="3" placeholder="e.g. I need a hotel in Chennai for 2 people from September 10 to 12, under ₹3,000 per night, preferably near the beach." required></textarea>
            <div class="agent-box-footer">
              <button type="submit" class="btn btn-primary">
                <i data-lucide="sparkles"></i> Ask the agent
              </button>
              <button type="button" class="btn btn-ghost" onclick="window.StayWiseState.navigateTo('manualSearch')">
                Prefer filters instead?
              </button>
            </div>
          </form>

          <div class="example-chips">
            ${EXAMPLES.map(ex => `<button type="button" class="chip" onclick="window.fillAgentExample(this)">${escapeHtml(shorten(ex))}</button>`).join("")}
          </div>
        </div>
      </section>

      <section class="how-it-works">
        <h2>How the agent works</h2>
        <ol class="agent-flow">
          <li><span class="step-num">1</span><div><strong>Understand intent</strong><p>Works out that you're searching for a hotel, not just chatting.</p></div></li>
          <li><span class="step-num">2</span><div><strong>Extract details</strong><p>Pulls out location, dates, guest count, budget and preferences from your sentence.</p></div></li>
          <li><span class="step-num">3</span><div><strong>Search & filter</strong><p>Runs those details against available hotels and narrows down the list.</p></div></li>
          <li><span class="step-num">4</span><div><strong>Compare & recommend</strong><p>Ranks the shortlist by price, rating and distance, and hands you the best 3–5.</p></div></li>
        </ol>
      </section>

      <div id="agent-overlay" class="agent-overlay hidden">
        <div class="agent-overlay-card">
          <div class="agent-spinner"></div>
          <h3>Agent is working on it…</h3>
          <ul id="agent-steps" class="agent-steps"></ul>
        </div>
      </div>
    `;
  }

  function manualSearchView(state) {
    return `
      <section class="manual-search">
        <h2>Search by filters</h2>
        <p class="muted">If you'd rather not describe your trip in a sentence, use the form below — it runs through the same search engine.</p>
        <form id="manual-form" class="manual-form" onsubmit="return window.handleManualSearch(event)">
          <label>City
            <select name="city" required>
              <option value="">Select a city</option>
              <option value="chennai">Chennai</option>
              <option value="goa">Goa</option>
              <option value="bangalore">Bangalore</option>
              <option value="mumbai">Mumbai</option>
              <option value="ooty">Ooty</option>
            </select>
          </label>
          <label>Guests
            <input type="number" name="guests" min="1" max="8" value="2" />
          </label>
          <label>Max budget per night (₹)
            <input type="number" name="budget" min="500" step="100" placeholder="e.g. 3000" />
          </label>
          <label>Preference
            <select name="preference">
              <option value="">No preference</option>
              <option value="beach">Near the beach</option>
              <option value="city">City centre</option>
              <option value="hills">Hill / valley view</option>
              <option value="pool">Has a pool</option>
              <option value="breakfast">Breakfast included</option>
            </select>
          </label>
          <button type="submit" class="btn btn-primary btn-block">Search hotels</button>
        </form>
        <button class="btn btn-ghost" onclick="window.StayWiseState.navigateTo('landing')">← Back to agent search</button>
      </section>
    `;
  }

  function shorten(text) {
    return text.length > 46 ? text.slice(0, 44) + "…" : text;
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, s => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[s]);
  }

  window.fillAgentExample = function (btn) {
    const idx = Array.from(btn.parentElement.children).indexOf(btn);
    document.getElementById("agent-input").value = EXAMPLES[idx];
  };

  window.handleAgentSearch = function (event) {
    event.preventDefault();
    const text = document.getElementById("agent-input").value.trim();
    if (!text) return false;
    runAgentWithAnimation(text);
    return false;
  };

  window.handleManualSearch = function (event) {
    event.preventDefault();
    const form = event.target;
    const parts = [];
    if (form.city.value) parts.push("hotel in " + form.city.value);
    if (form.guests.value) parts.push("for " + form.guests.value + " people");
    if (form.budget.value) parts.push("under " + form.budget.value + " per night");
    if (form.preference.value) {
      const labelMap = { beach: "near the beach", city: "in the city centre", hills: "in the hills", pool: "with a pool", breakfast: "with breakfast" };
      parts.push(labelMap[form.preference.value] || "");
    }
    runAgentWithAnimation(parts.join(" "));
    return false;
  };

  function runAgentWithAnimation(text) {
    const overlay = document.getElementById("agent-overlay");
    const stepsList = document.getElementById("agent-steps");
    if (!overlay || !stepsList) {
      finishAgentRun(text);
      return;
    }
    overlay.classList.remove("hidden");
    stepsList.innerHTML = "";

    AGENT_STEPS.forEach((label, i) => {
      setTimeout(() => {
        const li = document.createElement("li");
        li.className = "agent-step-item";
        li.innerHTML = `<i data-lucide="check-circle-2"></i> <span>${label}</span>`;
        stepsList.appendChild(li);
        if (window.lucide) window.lucide.createIcons();
        if (i === AGENT_STEPS.length - 1) {
          setTimeout(() => finishAgentRun(text), 450);
        }
      }, i * 260);
    });
  }

  function finishAgentRun(text) {
    if (N8N_WEBHOOK_URL) {
      fetch(N8N_WEBHOOK_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: text })
      })
        .then(res => {
          if (!res.ok) throw new Error("n8n webhook returned " + res.status);
          return res.json();
        })
        .then(data => {
          window.StayWiseState.set({
            lastQueryText: text,
            lastAgentInfo: data.info,
            searchResults: data.results,
            agentSummary: data.summary
          });
          window.StayWiseState.navigateTo("results");
        })
        .catch(err => {
          console.warn("n8n webhook unavailable, falling back to local agent:", err);
          runLocalAgent(text);
        });
    } else {
      runLocalAgent(text);
    }
  }

  function runLocalAgent(text) {
    const outcome = window.StayWiseAgent.runAgent(text);
    window.StayWiseState.set({
      lastQueryText: text,
      lastAgentInfo: outcome.info,
      searchResults: outcome.results,
      agentSummary: typeof outcome.recommendation === "string" ? outcome.recommendation : outcome.recommendation.summary
    });
    window.StayWiseState.navigateTo("results");
  }

  window.StayWiseViews.landing = landingView;
  window.StayWiseViews.manualSearch = manualSearchView;
})();
