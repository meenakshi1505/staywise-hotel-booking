/* ==========================================================================
   StayWise - My Bookings View
   ========================================================================== */
(function () {
  window.StayWiseViews = window.StayWiseViews || {};

  function myBookingsView(state) {
    const bookings = state.bookings || [];

    return `
      <section class="bookings-page">
        <h2>My bookings</h2>
        ${bookings.length === 0 ? `
          <div class="empty-state">
            <i data-lucide="calendar-x"></i>
            <h3>No bookings yet</h3>
            <p>Once you complete a booking, it will show up here.</p>
            <button class="btn btn-primary" onclick="window.StayWiseState.navigateTo('landing')">Search hotels</button>
          </div>
        ` : `
          <div class="booking-list">
            ${bookings.map(renderBookingRow).join("")}
          </div>
        `}
      </section>
    `;
  }

  function renderBookingRow(b) {
    const isCancelled = b.status === "cancelled";
    return `
      <article class="booking-row ${isCancelled ? 'cancelled' : ''}">
        <div class="booking-row-head">
          <h3>${escapeHtml(b.hotelName)}</h3>
          <span class="status-pill ${isCancelled ? 'status-cancelled' : 'status-confirmed'}">${isCancelled ? 'Cancelled' : 'Confirmed'}</span>
        </div>
        <p class="muted">${escapeHtml(b.roomType)} · ${escapeHtml(b.guest.checkin)} → ${escapeHtml(b.guest.checkout)}</p>
        <p class="muted small">Booking ID ${b.id} · ₹${b.totals.total.toLocaleString("en-IN")} paid via ${cap(b.paymentMethod)}</p>
        ${!isCancelled ? `<button class="btn btn-danger-outline" onclick="window.cancelBooking('${b.id}')">Cancel booking</button>` : ""}
      </article>
    `;
  }

  window.cancelBooking = function (id) {
    if (confirm("Cancel this booking?")) {
      window.StayWiseState.cancelBooking(id);
    }
  };

  function cap(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }
  function escapeHtml(str) {
    return String(str || "").replace(/[&<>"']/g, s => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[s]);
  }

  window.StayWiseViews.myBookings = myBookingsView;
})();
