/* ==========================================================================
   StayWise - Coupon + Payment View
   ========================================================================== */
(function () {
  window.StayWiseViews = window.StayWiseViews || {};

  function nights(checkin, checkout) {
    const d1 = new Date(checkin), d2 = new Date(checkout);
    const diff = Math.round((d2 - d1) / (1000 * 60 * 60 * 24));
    return Math.max(diff, 1);
  }

  function computeTotals(room, guest, coupon) {
    const n = nights(guest.checkin, guest.checkout);
    const subtotal = room.price * n;
    let discount = 0;
    if (coupon) {
      if (subtotal >= coupon.minAmount) {
        discount = coupon.type === "percent" ? Math.round(subtotal * coupon.value / 100) : coupon.value;
      }
    }
    const taxes = Math.round((subtotal - discount) * 0.12);
    const total = subtotal - discount + taxes;
    return { nights: n, subtotal, discount, taxes, total };
  }

  function paymentView(state) {
    const hotel = window.StayWiseState.findHotel(state.selectedHotelId);
    const room = window.StayWiseState.findRoom(hotel, state.selectedRoomId);
    const guest = state.guestDetails;
    if (!hotel || !room || !guest) {
      return `<section class="empty-state"><p>Please complete guest details first.</p>
        <button class="btn btn-primary" onclick="window.StayWiseState.navigateTo('landing')">Start a search</button></section>`;
    }

    const coupon = state.appliedCoupon ? window.StayWiseData.COUPONS[state.appliedCoupon] : null;
    const totals = computeTotals(room, guest, coupon);

    return `
      <section class="payment-page">
        <button class="btn btn-ghost" onclick="window.StayWiseState.navigateTo('guestDetails')">← Back to guest details</button>
        <h2>Review & pay</h2>

        <div class="summary-card">
          <h3>${escapeHtml(hotel.name)}</h3>
          <p class="muted">${escapeHtml(room.type)} · ${totals.nights} night${totals.nights > 1 ? "s" : ""} · ${guest.guests} guest${guest.guests > 1 ? "s" : ""}</p>
          <p class="muted">${escapeHtml(guest.checkin)} → ${escapeHtml(guest.checkout)}</p>

          <div class="coupon-row">
            <input type="text" id="coupon-input" placeholder="Coupon code (try SAVE10)" value="${state.appliedCoupon || ''}" />
            <button class="btn btn-secondary" onclick="window.applyCoupon()">Apply</button>
          </div>
          <div id="coupon-msg" class="coupon-msg"></div>

          <div class="totals">
            <div><span>Room subtotal</span><span>₹${totals.subtotal.toLocaleString("en-IN")}</span></div>
            ${totals.discount ? `<div class="discount-row"><span>Coupon discount</span><span>-₹${totals.discount.toLocaleString("en-IN")}</span></div>` : ""}
            <div><span>Taxes & fees (12%)</span><span>₹${totals.taxes.toLocaleString("en-IN")}</span></div>
            <div class="totals-final"><span>Total payable</span><span>₹${totals.total.toLocaleString("en-IN")}</span></div>
          </div>
        </div>

        <div class="summary-card">
          <h3>Payment method</h3>
          <div class="pay-methods" id="pay-methods">
            <label class="pay-method active"><input type="radio" name="method" value="upi" checked /> UPI</label>
            <label class="pay-method"><input type="radio" name="method" value="card" /> Credit / Debit card</label>
            <label class="pay-method"><input type="radio" name="method" value="netbanking" /> Net banking</label>
          </div>
          <p class="muted small">This is a simulated payment for demo purposes — no real transaction is made.</p>
          <button class="btn btn-primary btn-block" onclick="window.handlePayment()">
            Pay ₹${totals.total.toLocaleString("en-IN")} now
          </button>
        </div>
      </section>
    `;
  }

  window.applyCoupon = function () {
    const input = document.getElementById("coupon-input");
    const msg = document.getElementById("coupon-msg");
    const code = input.value.trim().toUpperCase();
    const coupon = window.StayWiseData.COUPONS[code];
    if (!coupon) {
      msg.textContent = "That coupon code isn't valid.";
      msg.className = "coupon-msg error";
      window.StayWiseState.set({ appliedCoupon: null });
      return;
    }
    msg.textContent = "Applied: " + coupon.description;
    msg.className = "coupon-msg success";
    window.StayWiseState.set({ appliedCoupon: code });
  };

  window.handlePayment = function () {
    const state = window.StayWiseState.get();
    const hotel = window.StayWiseState.findHotel(state.selectedHotelId);
    const room = window.StayWiseState.findRoom(hotel, state.selectedRoomId);
    const guest = state.guestDetails;
    const coupon = state.appliedCoupon ? window.StayWiseData.COUPONS[state.appliedCoupon] : null;
    const totals = computeTotals(room, guest, coupon);
    const methodInput = document.querySelector('#pay-methods input[name="method"]:checked');

    const booking = {
      id: "BK" + Date.now().toString().slice(-8),
      hotelId: hotel.id,
      hotelName: hotel.name,
      roomType: room.type,
      guest: guest,
      coupon: state.appliedCoupon,
      paymentMethod: methodInput ? methodInput.value : "upi",
      totals: totals,
      status: "confirmed",
      bookedAt: new Date().toISOString()
    };

    window.StayWiseState.addBooking(booking);
    window.StayWiseState.set({ lastBooking: booking });
    window.StayWiseState.navigateTo("confirmation");
  };

  function escapeHtml(str) {
    return String(str || "").replace(/[&<>"']/g, s => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[s]);
  }

  window.StayWiseViews.payment = paymentView;
  window.StayWisePaymentUtils = { computeTotals, nights };
})();
