/* ==========================================================================
   StayWise - Search Results View
   ========================================================================== */
(function () {
  window.StayWiseViews = window.StayWiseViews || {};

  function resultsView(state) {
    const info = state.lastAgentInfo;
    const results = state.searchResults || [];
    const top = results.slice(0, 5);

    return `
      <section class="results-page">
        <button class="btn btn-ghost" onclick="window.StayWiseState.navigateTo('landing')">← New search</button>

        <div class="agent-bubble">
          <i data-lucide="bot"></i>
          <div>
            <p class="agent-bubble-quote">"${escapeHtml(state.lastQueryText)}"</p>
            <p class="agent-bubble-summary">${escapeHtml(state.agentSummary)}</p>
            ${renderExtractedInfo(info)}
          </div>
        </div>

        ${top.length === 0 ? renderEmptyState() : `
          <div class="results-grid">
            ${top.map((h, i) => renderHotelCard(h, i)).join("")}
          </div>
        `}
      </section>
    `;
  }

  function renderExtractedInfo(info) {
    if (!info) return "";
    const chips = [];
    if (info.city) chips.push(cap(info.city));
    if (info.guests) chips.push(info.guests + " guests");
    if (info.budget) chips.push("≤ ₹" + info.budget.toLocaleString("en-IN") + "/night");
    if (info.checkin && info.checkout) chips.push(info.checkin + " – " + info.checkout);
    info.preferences.forEach(p => chips.push(cap(p)));
    if (!chips.length) return "";
    return `<div class="extracted-chips">${chips.map(c => `<span class="mini-chip">${escapeHtml(c)}</span>`).join("")}</div>`;
  }

  function renderEmptyState() {
    return `
      <div class="empty-state">
        <i data-lucide="search-x"></i>
        <h3>No hotels matched every filter</h3>
        <p>Try removing the budget cap or a preference, or start a new search.</p>
        <button class="btn btn-primary" onclick="window.StayWiseState.navigateTo('landing')">Try another search</button>
      </div>
    `;
  }

  function renderHotelCard(hotel, index) {
    return `
      <article class="hotel-card">
        <div class="hotel-card-media" style="background:${hotel.accent}">
          <span class="hotel-card-rank">#${index + 1}</span>
          <i data-lucide="building-2"></i>
        </div>
        <div class="hotel-card-body">
          <div class="hotel-card-head">
            <h3>${escapeHtml(hotel.name)}</h3>
            <span class="rating-pill"><i data-lucide="star"></i> ${hotel.rating}</span>
          </div>
          <p class="hotel-card-loc">${escapeHtml(hotel.area)} · ${escapeHtml(hotel.distanceLabel)}</p>
          <div class="hotel-card-tags">
            ${hotel.tags.slice(0, 3).map(t => `<span class="mini-chip">${cap(t)}</span>`).join("")}
          </div>
          <div class="hotel-card-foot">
            <div>
              <span class="price">₹${hotel.pricePerNight.toLocaleString("en-IN")}</span>
              <span class="muted"> / night</span>
            </div>
            <button class="btn btn-secondary" onclick="window.viewHotel('${hotel.id}')">View details</button>
          </div>
        </div>
      </article>
    `;
  }

  window.viewHotel = function (hotelId) {
    window.StayWiseState.set({ selectedHotelId: hotelId, selectedRoomId: null });
    window.StayWiseState.navigateTo("hotelDetails");
  };

  function cap(s) { return s.charAt(0).toUpperCase() + s.slice(1); }
  function escapeHtml(str) {
    return String(str || "").replace(/[&<>"']/g, s => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[s]);
  }

  window.StayWiseViews.results = resultsView;
})();
