/* ==========================================================================
   StayWise - Room Selection View
   ========================================================================== */
(function () {
  window.StayWiseViews = window.StayWiseViews || {};

  function roomsView(state) {
    const hotel = window.StayWiseState.findHotel(state.selectedHotelId);
    if (!hotel) {
      return `<section class="empty-state"><p>No hotel selected.</p>
        <button class="btn btn-primary" onclick="window.StayWiseState.navigateTo('landing')">Start a search</button></section>`;
    }

    return `
      <section class="rooms-page">
        <button class="btn btn-ghost" onclick="window.StayWiseState.navigateTo('hotelDetails')">← Back to ${escapeHtml(hotel.name)}</button>
        <h2>Choose a room</h2>
        <p class="muted">${escapeHtml(hotel.name)} · ${escapeHtml(hotel.area)}</p>

        <div class="room-list">
          ${hotel.rooms.map(r => renderRoomRow(hotel, r)).join("")}
        </div>
      </section>
    `;
  }

  function renderRoomRow(hotel, room) {
    return `
      <article class="room-row">
        <div class="room-row-info">
          <h3>${escapeHtml(room.type)}</h3>
          <p class="muted">Sleeps up to ${room.capacity} guests</p>
          <div class="hotel-card-tags">
            ${room.amenities.map(a => `<span class="mini-chip">${escapeHtml(a)}</span>`).join("")}
          </div>
        </div>
        <div class="room-row-cta">
          <span class="price">₹${room.price.toLocaleString("en-IN")}</span>
          <span class="muted">/ night</span>
          <button class="btn btn-primary" onclick="window.selectRoom('${room.id}')">Select room</button>
        </div>
      </article>
    `;
  }

  window.selectRoom = function (roomId) {
    window.StayWiseState.set({ selectedRoomId: roomId });
    window.StayWiseState.navigateTo("guestDetails");
  };

  function escapeHtml(str) {
    return String(str || "").replace(/[&<>"']/g, s => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[s]);
  }

  window.StayWiseViews.rooms = roomsView;
})();
